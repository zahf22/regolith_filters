import { informationMenu } from "./informationMenu";
import { guidebook } from "./guidebook";
import { creditsInformation, getSettingForm, informationIcons, itemsInformation, mainMenu, mobAndBossData, trinketsInformation, weaponsInformation } from "./index";
import { showBasicModalForm } from "./settingsMenu";
import { system } from "@minecraft/server";
import { checkEquipment, identifier } from "../utils";

export const specialActions = {
    supports: (player) => {
        const entity = player.dimension.spawnEntity('5fs_br:guidebook', player.getHeadLocation());
        player.addTag(`5fs_br:guidebook`);
        entity.addTag(`5fs_br:${player.id}`);

        // Lock player movement
        player.inputPermissions.setPermissionCategory(4, false);
        player.inputPermissions.setPermissionCategory(1, false);
        player.teleport(player.location, {
            rotation: { x: 0, y: player.getRotation().y }
        });

        // Store interval ID
        const guidebookId = system.runInterval(() => {
            player.runCommand(`tp @e[tag=5fs_br:${player.id}, c=1] ^^1.2^1.5 facing @s`);
            player.onScreenDisplay.setActionBar("Sneak to Close");

            if (player.isSneaking || checkEquipment(player, 'Mainhand')?.typeId !== identifier('guidebook')) {
                // Restore permissions
                player.inputPermissions.setPermissionCategory(4, true);
                player.inputPermissions.setPermissionCategory(1, true);
                player.removeTag(`5fs_br:guidebook`);

                // Remove entity safely
                if (entity.isValid()) entity.remove();

                // Stop interval before opening UI
                system.clearRun(guidebookId);
                if (checkEquipment(player, 'Mainhand')?.typeId === identifier('guidebook')) {
                    guidebook(player, 'main_menu'); // ✅ Open menu AFTER clearing interval
                }
            }
        });
    },
    credits: (player) => {
        informationMenu(player, creditsInformation["credits"], "main_menu");
    },
    settings: (player) => {
        if (player.getGameMode() === 'creative') {
            player.playSound('note.pling');
            showBasicModalForm(player, getSettingForm()); // ✅ Uses fresh values
        } else {
            player.playSound('note.bass');
            informationMenu(player, creditsInformation["game_mode"], "main_menu");
        }
    }
};


// ✅ Create buttons while correctly handling special actions
const createButtons = (category, dataSource, actionType = "guidebook") => {
    return Object.entries(dataSource).map(([key, item]) => {
        const icon = informationIcons[key] ?? informationIcons.default;

        return {
            name: item.guidebook_name,
            ...(icon !== null ? { icon } : {}), // Only include `icon` if it's not null
            method: (player) => {
                if (specialActions[key]) {
                    specialActions[key](player); // Run special actions immediately
                } else if (actionType === "guidebook") {
                    guidebook(player, key, category);
                } else if (actionType === "menu") {
                    informationMenu(player, item, category);
                } else if (typeof actionType === "function") {
                    actionType(player, key, category);
                } else {
                    console.warn(`Unknown action type: ${actionType}`);
                }
            }
        };
    });
};

// ✅ Example Usage (Normal buttons)
const mainMenuButtons = createButtons("main_menu", mainMenu, "guidebook");
const creaturesButtons = createButtons("creatures", mobAndBossData, "menu");
const trinketsButtons = createButtons("trinkets", trinketsInformation, "menu");
const weaponsButtons = createButtons("equipments", weaponsInformation, "menu");
const itemsButtons = createButtons("items", itemsInformation, "menu");

// ✅ Final `buttonData` object
export const buttonData = {
    main_menu: mainMenuButtons,
    // creatures: creaturesButtons,
    // items: itemsButtons,
    // equipments: weaponsButtons,
    trinkets: trinketsButtons
    // supports: [
    //     { name: "Credits", icon: "textures/ui/icon_book.png", method: specialActions.credits }
    // ],
    // credits: [
    //     { name: "Credits", icon: "textures/ui/icon_book.png", method: specialActions.credits }
    // ],
    // settings: [
    //     { name: "Settings", icon: "textures/ui/icon_settings.png", method: specialActions.settings }
    // ]
};
