import { ModalFormData } from "@minecraft/server-ui";

export function showBasicModalForm(player, formFields, submitButton = 'Submit', title = "Game Settings") {
  if (!player) {
    console.error("❌ No player provided for the modal form.");
    return;
  }

  const modalForm = new ModalFormData().title(title);

  // Dynamically add form fields
  formFields.forEach(field => {
    switch (field.type) {
      case "toggle":
        modalForm.toggle(field.label, field.defaultValue);
        break;
      case "slider":
        modalForm.slider(field.label, field.min, field.max, field.step, field.defaultValue ?? field.min);
        break;
      case "dropdown":
        modalForm.dropdown(field.label, field.options, field.defaultValue ?? 0);
        break;
      default:
        console.warn(`⚠️ Unknown field type: ${field.type}`);
    }
  });

  modalForm.submitButton(submitButton);

  return modalForm.show(player)
    .then((formData) => {
      if (!formData || formData.canceled) {
        console.log("⏹️ Player canceled the form.");
        return;
      }

      const values = formData.formValues;
      if (!values || values.length !== formFields.length) {
        console.warn("⚠️ Mismatch between form fields and submitted values.");
        return;
      }

      // Execute onSubmit function for each field
      formFields.forEach((field, index) => {
        if (typeof field.onSubmit === "function") {
          try {
            field.onSubmit(player, values[index]);
          } catch (error) {
            console.error(`❌ Error executing onSubmit for "${field.label}":`, error);
          }
        }
      });
    })
    .catch((error) => {
      console.error("❌ Failed to show form:", error);
    });
}
