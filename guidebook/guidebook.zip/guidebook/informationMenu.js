import { guidebook } from "./guidebook";
import * as h from './helper';

// Helper function to generate grid dynamically
function generateCraftingGrid(pattern, slots) {
    const totalSlots = Object.keys(pattern).length;
    const size = Math.sqrt(totalSlots);
    let gridLines = [];

    for (let row = 0; row < size; row++) {
        let rowStr = "            ";
        for (let col = 0; col < size; col++) {
            const index = row * size + col + 1; // slot indices start at 1
            const slotKey = `slot_${index}`;
            const itemLetter = pattern[slotKey]; // get the letter assigned to this slot
            const itemData = itemLetter ? slots[itemLetter] : null; // get item data for the letter
            const displayText = itemData ? itemData.item.replace('minecraft:', '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : '-';
            rowStr += `[ ${h.getColorForLetter(itemLetter)}${itemLetter || '-'}§r ]`;
        }
        gridLines.push(rowStr);
        if (row < size - 1) {
            gridLines.push("            -----------");
        }
    }
    return gridLines.join("\n");
}

export async function informationMenu(source, label, backMenu) {
    const craftingGuideData = label; // Retrieve specific recipe data

    // Validate recipe data
    if (!craftingGuideData || !craftingGuideData.guidebook_description || !craftingGuideData.guidebook_name) {
        console.error("Invalid recipe data for", label);
        return;
    }

    // Construct items list
    const itemsList = craftingGuideData.recipe
        ? Object.entries(craftingGuideData.recipe)
            .map(([key, value]) => `${h.getColorForLetter(key)}${key}§r = ${value.item.split(':')[1].replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}`)
            .join("\n")
        : "";

    // Generate crafting grid
    const patternData = craftingGuideData.pattern;
    const slotsData = craftingGuideData.recipe; // Use recipe data for items
    const craftingGrid = generateCraftingGrid(patternData, slotsData);

    // Build description
    const guideDescription = `
${craftingGuideData.guidebook_description.replace('~LINEBREAK~', '\n')}\n§r
${craftingGuideData.recipe ? `\n§aCrafting:§r\n${craftingGrid}\n` : ''}
${itemsList ? `\n§aItems:§r\n${itemsList}\n` : ''}
`;

    // Create form
    const craftingGuide = h.createSimpleActionForm(
        `§0${craftingGuideData.guidebook_name}`,
        guideDescription,
        "Back"
    );

    // Handle back navigation
    await h.handleBackNavigation(source, craftingGuide, async () => {
        if (backMenu === 'main_menu') {
            await guidebook(source, "main_menu");
        } else {
            await guidebook(source, backMenu, "main_menu");
        }
    });
}