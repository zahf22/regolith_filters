import * as ui from "@minecraft/server-ui";
import { buttonData, specialActions } from "./buttonData";

// ✅ Create guidebook UI
function createGuidebookForm(category, backCategory) {
    if (!buttonData[category]) {
        console.error(`Category "${category}" not found in button data.`);
        return null;
    }

    const guideForm = new ui.ActionFormData();
    guideForm.title("§lSmilers Add-On");

    buttonData[category].forEach((button) => {
        guideForm.button(button.name, button.icon ?? undefined);
    });

    if (backCategory) {
        guideForm.button("§cBack");
    }

    return guideForm;
}

// ✅ Main guidebook function
export async function guidebook(player, category, backCategory = null) {
    console.log(`Opening guidebook for category: ${category}`);

    // ✅ If category is a special action → Run it immediately
    if (category in specialActions) {
        console.log(`Executing special action: ${category}`);
        specialActions[category](player);
        return;
    }

    // ✅ Create and show the guidebook form
    const guideForm = createGuidebookForm(category, backCategory);
    if (!guideForm) return;

    await guideForm.show(player).then((toggleResult) => {
        if (toggleResult.canceled) {
            console.log(`Player ${player.name} canceled the guide form.`);
            return;
        }

        const selectedIndex = toggleResult.selection;
        const backButtonIndex = backCategory ? buttonData[category].length : -1;

        // ✅ Handle "Back" button
        if (selectedIndex === backButtonIndex) {
            console.log(`Player clicked back, returning to: ${backCategory}`);
            guidebook(player, backCategory);
            return;
        }

        // ✅ Get selected button
        const selectedButton = buttonData[category][selectedIndex];
        if (!selectedButton) {
            console.error(`Invalid selection index: ${selectedIndex}`);
            return;
        }

        console.log(`Player selected: ${selectedButton.guidebook_name}`);

        // ✅ Execute button method
        try {
            player.playSound('note.pling')
            selectedButton.method(player);
        } catch (error) {
            console.error(`Error executing method for button: ${selectedButton.guidebook_name} - ${error.message}`);
        }
    }).catch((error) => {
        console.error(`Error displaying guide form: ${error.message}`);
    });
}
