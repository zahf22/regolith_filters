export const trinketsInformation = {
    augmenting_table: {
        guidebook_name: "Augmenting Table",
        guidebook_description: "Table for Augmenting ",
        recipe: { "A": { "item": "5fs_br:steel_spike" }, "B": { "item": "5fs_br:chupacabra_core" }, "C": { "item": "minecraft:blackstone" }, "D": { "item": "minecraft:elytra" }, "E": { "item": "minecraft:bone_block" }, "F": { "item": "minecraft:netherrack" } },
        pattern: { "slot_1": "A", "slot_2": "B", "slot_3": null, "slot_4": "C", "slot_5": "D", "slot_6": "C", "slot_7": "E", "slot_8": "F", "slot_9": "E" }
    },
    enchantment_library: {
        guidebook_name: "Augmenting Table",
        guidebook_description: "Table for~LINEBREAK~ Augmenting ",
        recipe: { "A": { "item": "5fs_br:steel_spike" }, "B": { "item": "5fs_br:chupacabra_core" }, "C": { "item": "minecraft:blackstone" }, "D": { "item": "minecraft:elytra" }, "E": { "item": "minecraft:bone_block" }, "F": { "item": "minecraft:netherrack" } },
        pattern: { "slot_1": "A", "slot_2": "B", "slot_3": null, "slot_4": "C", "slot_5": "D", "slot_6": "C", "slot_7": "E", "slot_8": "F", "slot_9": "E" }
    }
};
