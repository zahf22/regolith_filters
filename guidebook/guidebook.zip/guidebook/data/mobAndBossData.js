export const mobAndBossData = {
    "faceless_spawner": {
        name: "Faceless",
        description: "The Faceless, a creature renowned for its tall figure and pale white face. It can be found roaming Dark Oak Forests and upon death can drop a Faceless Core, Tattered Cloth and a Faceless Pet."
    },
    "smiler_spawner": {
        name: "Smiler",
        description: "A Pair of glowing eyes and mouth. This creature can be found lurking in caves below Y50 ready to surprise you at any turn. Upon death it can drop a Smiler Core, Spectral Essence."
    },
    "crawler_spawner": {
        name: "Crawler",
        description: "A spider that has been covered in fungus taking control of its limbs. If you're not careful you could be next as it can entangle you in its web. The Crawler can be found roaming the Taiga Forests and upon death can drop a Crawler Core and Spectral Essence."
    },
    "scit_spawner": {
        name: "Scits",
        description: 'A small adorable creature with a vicious side hidden underneath. It lurks the waters of the cold oceans waiting to attack and ravage its prey. This creature can be found roaming Cold Oceans and upon death can drop a Scits Core, Scales.'
    },
    "hound_spawner": {
        name: "Hound",
        description: "A ravenous creature known for its ferocity, some say you won't see it coming.  It can be found roaming the Plains biome at night. Upon death it can drop a Hound Core, Scales and Tattered Cloth"
    },
    "entity_0_spawner": {
        name: "Entity 0",
        description: "A slender pitch black figure that looms in the darkness of the Deepslate Caverns below Y0. Upon death it can drop a Entity 0 Core. Spectral Essence and Tattered Cloth."
    },
    "swamp_spawner": {
        name: "Swamp Monster",
        description: "A plant that has spiraled out of control inducing all sorts of mutations, abilities and growth. It can be found roaming Swamps. Upon death it can drop a Swamp Monster Core, Tattered Cloth and Scales."
    },
    "deathmoth_spawner": {
        name: "Deathmoth",
        description: "A large mutated moth surrounded by its offspring. The Deathmoth can be found roaming Jungles but don't get too close otherwise you could become its next victim. Upon death it can drop a Deathmoth Core, Scales and Marionette String."
    },
    "bone_thieves_spawner": {
        name: "Bone Thieves",
        description: "The Bone Thieves is a creature that is constantly crying and trying to blend into its surroundings but don't be fooled, it can mimick the sounds of other creatures to bait its victim to coming closer. The Bone Thieves can be found in Deserts and upon death can drop a Thieves Core, Tattered Cloth."
    },
    "memory_worm_spawner": {
        name: "Memory Worm",
        description: "The Memory Worm is a creature that can grab its victim causing them eternal suffocation. It can be found roaming or burrowing around Beaches. Upon death it can drop a Memory Core, Scales and Steel Spikes"
    },
    "game_master_spawner": {
        name: "Game Master",
        description: "The Game Master, a clown like creature offering countless surprises and tricks to trap its victim. The Game Master can be found roaming Badlands. Upon death it can drop a Game Core, Marionette Strings."
    },
    "carnivorous_balloon_spawner": {
        name: "Carnivorous Balloon",
        description: "A floating red balloon that glides in the wind waiting to attach to its next victim. It can be found gliding through Savannah Biomes. Upon death it can drop a Balloon Core, Spectral Essence and Marionette Strings."
    },
    "party_goer_spawner": {
        name: "Partygoer",
        description: "The Partygoer, a creepy entity with an eternal smile and its very own Carnivorous Balloon. It can be found roaming Sunflower Plains biomes. Upon death it can drop a Party Core, Marionette String and Tattered Cloth."
    },
    "hunter_spawner": {
        name: "Hunter",
        description: "A spider like creature of unknown origin. Reports indicate it can be located in the End Dimension. Upon death it can drop a Hunter Core, Spectral Essence, Marionette String."
    },
    "chupacabra_spawner": {
        name: "Chupacabra",
        description: "A mutated creature that has adapted into its environment feeding off the lost souls scouring its territory. It seems to be roaming the Nether Dimension within Crimson Forests. Upon death it can drop a Chupacabra Core, Scales and Steel Spikes."
    }
}