export const weaponsInformation = {
    "faceless_pet": {
        "name": "Faceless Pet",
        "description": "A rare friendly Faceless that helps the player perform specific actions and can also be picked up. This pet has a chance to appear when killing Faceless and can be tamed using Tattered Cloth."

    },
    "attachable_balloon": {
        name: "Attachable Balloon",
        slot1: "A",
        slot2: "A",
        slot3: "A",
        slot4: "B",
        slot5: "C",
        slot6: "B",
        slot7: "D",
        slot8: "E",
        slot9: "D",
        description: "A weaponised Carnivorous Balloon. It can be attached to targets by interacting on them, causing them to levitate and explode. The Attachable Balloon can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Red Wool",
            B: "Spectral Essence",
            C: "Diamond",
            D: "Marionette String",
            E: "Balloon Core"
        }
    },
    "chupacabra_skull": {
        name: "Chupacabra Skull",
        slot1: "A",
        slot2: "B",
        slot3: "C",
        slot4: "C",
        slot5: "D",
        slot6: "B",
        slot7: "C",
        slot8: "C",
        slot9: "C",
        description: "A handheld skull of the Chupacabra. When interacting with it, it propel a fireball forwards towards the target. The Chupacabra Skull can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Steel Spike",
            B: "Scales",
            C: "Bone Block",
            D: "Chupacabra Core"
        }
    },
    "chupacabra_wings": {
        name: "Chupacabra Wings",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "C",
        slot5: "D",
        slot6: "C",
        slot7: "E",
        slot8: "F",
        slot9: "E",
        description: "A pair of wings that can be worn granting the wearer temporary flight and fiery thorns. Entities that damage the player are set on fire when these wings are worn. The Chupacabra Wings are craftable. Find the recipe in the crafting table.",
        items: {
            A: "Steel Spike",
            B: "Chupacabra Core",
            C: "Blackstone",
            D: "Elytra",
            E: "Bone Block",
            F: "Netherrack"
        }
    },
    "deathmoth_wings": {
        name: "Deathmoth Wings",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "C",
        slot5: "D",
        slot6: "C",
        slot7: "A",
        slot8: "C",
        slot9: "A",
        description: "Wings plucked from the corpse of a Deathmoth. It grants the wearer temporary flight but the wearer will take double damage from all forms of fire. Upon flying with the wings you will also generate spores that inflict poison and slowness. The Deathmoth Wings can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Marionette String",
            B: "Elytra",
            C: "Scales",
            D: "Deathmoth Core"
        }
    },
    "flashlight": {
        name: "Flashlight",
        slot1: "A",
        slot2: "B",
        slot3: "B",
        slot4: "C",
        slot5: "D",
        slot6: "E",
        slot7: "A",
        slot8: "F",
        slot9: "B",
        description: "A toggleable light capable of emitting light where the user looks. To turn it on or off interact while holding it. The flashlight is craftable. Find the recipe in the crafting table.",
        items: {
            A: "White Wool",
            B: "Iron Ingot",
            C: "Observer",
            D: "Lantern",
            E: "Glass",
            F: "Lever"
        }
    },
    "crawler_staff": {
        name: "Crawler Staff",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "A",
        slot5: "C",
        slot6: "A",
        slot7: "C",
        description: "A staff made from the body of a Crawler. It can summon a mini Crawler to fight for you when interacting. The Crawler Staff can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Spectral Essence",
            B: "Crawler Core",
            C: "Stick"
        }
    },
    "game_master_dice": {
        name: "Game Master Dice",
        slot1: "A",
        slot2: "B",
        slot3: "C",
        slot4: "B",
        slot5: "D",
        slot6: "B",
        slot7: "E",
        slot8: "B",
        slot9: "F",
        description: "A batch of dice stolen from the Game Master. When thrown by interacting it is randomised into 3 colors each with varying abilities. These abilities being applying negative effects to the target, explosions or summoning minions. The Gamemasters Dice can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Orange Wool",
            B: "Marionette String",
            C: "Blue Wool",
            D: "Game Core",
            E: "Red Wool",
            F: "Lime Wool"
        }
    },
    "hound_dagger": {
        name: "Hound Dagger",
        slot1: "A",
        slot2: "B",
        slot3: "C",
        slot4: "D",
        slot5: "A",
        slot6: "E",
        slot7: "C",
        description: "A dagger made using the claws of the Hound. When interacting it can unleash a cross like slash jousting you forward. The Hound Dagger can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Scales",
            B: "Hound Core",
            C: "Tattered Cloth",
            D: "Iron Sword",
            E: "Stick"
        }
    },
    "hunter_mask": {
        name: "Hunter Mask",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "A",
        slot5: "C",
        slot6: "A",
        slot7: "D",
        slot8: "D",
        slot9: "D",
        description: "A wearable skull of The Hunter. Upon taking damage while wearing it, a roar is unleashed stunning all nearby entities. The Hunter Mask can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Bone Block",
            B: "Marionette String",
            C: "Hunter Core",
            D: "Spectral Essence"
        }
    },
    "memory_sword": {
        name: "Memory Sword",
        slot1: "A",
        slot2: "A",
        slot3: "B",
        slot4: "C",
        slot5: "A",
        slot6: "D",
        slot7: "B",
        description: "A sword constructed using the flesh and bones of the Memory Worm. Upon Interacting, the sword is thrust forward stealing a portion of the targets health healing the user and removing any positive effects from the target. The Memory Sword can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Steel Spike",
            B: "Scales",
            C: "Memory Core",
            D: "Iron Sword"
        }
    },
    "monster_spellbook": {
        name: "Monster Spell Book",
        slot1: "A",
        slot2: "B",
        slot3: "C",
        slot4: "B",
        slot5: "D",
        slot6: "B",
        slot7: "C",
        slot8: "B",
        slot9: "A",
        description: "A forbidden book capable of summoning the Swamp Monsters vines binding nearby targets in place for 15 seconds. The Monster Spellbook can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Scales",
            B: "Book",
            C: "Tattered Cloth",
            D: "Swamp Core"
        }
    },
    "scit_baghnakhs": {
        name: "Scit Baghnakhs",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "C",
        slot5: "A",
        slot6: "D",
        slot7: "A",
        description: "A pair of dagger like weapons made from the fangs of the Scits that chargeup and before being thrusted at the target inflicting damage overtime. The Scit Baghnakhs can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Scales",
            B: "Iron Ingot",
            C: "Scit Core",
            D: "Stick"
        }
    },
    "shadow_gauntlet": {
        name: "Shadow Gauntlet",
        slot1: "A",
        slot2: "B",
        slot3: "B",
        slot4: "C",
        slot5: "D",
        slot6: "C",
        slot7: "A",
        slot8: "B",
        slot9: "B",
        description: "A gauntlet made-up of the shadows consuming Entity 0. Upon interacting it begins to charge up a high powered punch hitting multiple targets in the area at once with heavy knockback. Targets hit by the punch are given darkness. The Shadow Gauntlet can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Tattered Cloth",
            B: "Cobbled Deepslate",
            C: "Spectral Essence",
            D: "Entity 0 Core"
        }
    },
    "facelesss_tuxedo": {
        name: "Facelesss Tuxedo",
        slot1: "A",
        slot2: "A",
        slot3: "A",
        slot4: "B",
        slot5: "A",
        slot6: "A",
        slot7: "A",
        slot8: "A",
        description: "The Tuxedo of the Faceless with its tentacles still intact. The Tuxedo can come alive and attack nearby targets and elevate the wearer up 5 blocks by digging its tentacles into the ground when Shift Interacting. The Faceless Tuxedo can be crafted. Find the recipe in the crafting table.",
        items: {
            A: "Tattered Cloth",
            B: "Faceless Core"
        }
    },
    "smiler_boomerang": {
        name: "Smiler Boomerang",
        slot1: "A",
        slot2: "B",
        slot3: "A",
        slot4: "C",
        slot5: "D",
        slot6: "E",
        slot7: "D",
        description: "A boomerang capable of being thrown that drags items and entities towards you. The Smiler Boomerang is craftable. Find the recipe in the crafting table.",
        items: {
            A: "Spectral Essence",
            B: "Iron Sword",
            C: "Smiler Core",
            D: "Iron Ingot",
            E: "Stick"
        }
    },
    "thieves_pet": {
        name: "Thieves Pet",
        slot1: "A",
        slot2: "B",
        slot3: "B",
        slot4: "C",
        slot5: "D",
        slot6: "E",
        slot7: "A",
        slot8: "B",
        slot9: "B",
        description: "Summons a friendly Bone Thieves that will prey on targets if they are to attack you while it is nearby. It is capable of leaping towards targets inflicting massive knockback and stunning them in place. The Thieves Pet is craftable. Find the recipe in the crafting table.",
        items: {
            A: "Tattered Cloth",
            B: "Sand",
            C: "Thieves Core",
            D: "Observer",
            E: "Tripwire Hook"
        }
    }
};