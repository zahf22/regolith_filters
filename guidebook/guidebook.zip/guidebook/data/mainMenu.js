export const mainMenu = {
    "trinkets": {
        guidebook_name: {rawtext: [{translate: "button.5fs_br.trinkets"}]}
    }
}