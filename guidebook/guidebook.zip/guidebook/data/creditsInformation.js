export const creditsInformation = {
    "credits": {
        guidebook_name: "Credits",
        guidebook_description: "Backrooms Fandom Wikipedia for their free-use sound effects."
    },
    "game_mode": {
        guidebook_name: "GAMEMODE",
        guidebook_description: "Your game mode needs to be set to Creative to manage settings."
    }
}