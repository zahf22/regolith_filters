import { world } from "@minecraft/server";

export function getWorldData() {
    const defaultWorldData = {
        mist: true,
        groundParticle: true,
        nightAura: true,
        ambience1: true,
        ambience2: true,
        redFog: true,
        darkFog: true,
        greenFog: true,
        soundEffects: true,
        darknessEffect: true
    };

    const existingData = world.getDynamicProperty("world_data");

    // ✅ Ensure data is a string before parsing
    if (typeof existingData === "string") {
        try {
            const parsedData = JSON.parse(existingData);
            return { ...defaultWorldData, ...parsedData };
        } catch (error) {
            console.error("Error parsing world_data:", error);
            return defaultWorldData; // ✅ Fallback if JSON is corrupted
        }
    }

    return defaultWorldData; // ✅ Return default values if data is missing
};

export function setWorldData(worldData) {
    const currentData = getWorldData(); // Get existing world data
    const mergedData = { ...currentData, ...worldData }; // Merge with new values
    world.setDynamicProperty("world_data", JSON.stringify(mergedData));
};

export function getSettingForm() {
  const worldData = getWorldData(); // Fetch fresh world data

  return [
    {
      type: "toggle",
      label: "Mist (smoke on the ground)",
      defaultValue: worldData.mist, // Dynamically set
      onSubmit: (player, value) => {
        setWorldData({ mist: value });
      }
    },
    {
      type: "toggle",
      label: "Ground Particle (particle on ground)",
      defaultValue: worldData.groundParticle,
      onSubmit: (player, value) => {
        setWorldData({ groundParticle: value });
      }
    },
    {
      type: "toggle",
      label: "Night Aura",
      defaultValue: worldData.nightAura,
      onSubmit: (player, value) => {
        setWorldData({ nightAura: value });
      }
    },
    {
      type: "toggle",
      label: "Ambience 1",
      defaultValue: worldData.ambience1,
      onSubmit: (player, value) => {
        setWorldData({ ambience1: value });
      }
    },
    {
      type: "toggle",
      label: "Ambience 2",
      defaultValue: worldData.ambience2,
      onSubmit: (player, value) => {
        setWorldData({ ambience2: value });
      }
    },
    {
      type: "toggle",
      label: "Red Fog (ambience fog)",
      defaultValue: worldData.redFog,
      onSubmit: (player, value) => {
        setWorldData({ redFog: value });
      }
    },
    {
      type: "toggle",
      label: "Green Fog (ambience fog)",
      defaultValue: worldData.greenFog,
      onSubmit: (player, value) => {
        setWorldData({ greenFog: value });
      }
    },
    {
      type: "toggle",
      label: "Dark Fog (ambience fog)",
      defaultValue: worldData.darkFog,
      onSubmit: (player, value) => {
        setWorldData({ darkFog: value });
      }
    },
    {
      type: "toggle",
      label: "Sound Effects",
      defaultValue: worldData.soundEffects,
      onSubmit: (player, value) => {
        setWorldData({ soundEffects: value });
      }
    },
    {
      type: "toggle",
      label: "Darkness Effect",
      defaultValue: worldData.darknessEffect,
      onSubmit: (player, value) => {
        setWorldData({ darknessEffect: value });
      }
    }
  ];
}
