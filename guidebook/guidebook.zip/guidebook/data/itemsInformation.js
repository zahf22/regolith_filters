export const itemsInformation = {
    "tattered_cloth": {
        name: "Tattered Cloth",
        description: "Shredded pieces of clothing dropped by various creatures from their previous hunts. It is used within various crafting recipes. Check a crafting table to check out how to craft with it."
    },
    "steel_spike": {
        name: "Steel Spike",
        description: "A fragment of a creatures teeth. It is used within various crafting recipes. Check a crafting table to check out how to craft with it."
    },
    "scales": {
        name: "Scales",
        description: "Scales skinned off a terrifying creatures husk. It is used within various crafting recipes. Check a crafting table to check out how to craft with it."
    },
    "marionette_string": {
        name: "Marionette String",
        description: "Strong string that was once used to bind people in place. It is used within various crafting recipes. Check a crafting table to check out how to craft with it."
    },
    "spectral_essence": {
        name: "Spectral Essence",
        description: "Essence of lost souls that had once inhabited creatures driving them mad. It is used within various crafting recipes. Check a crafting table to check out how to craft with it."
    },
    "cores": {
        name: "Cores",
        description: "Cores are the very heart of creatures. There are 15 total that can be obtained by slaying Smilers entities. These cores are used in the heart of crafting recipes for weapons or trinkets designed to give you some of the creatures abilities, mimic some attributes or become immune to some effects. To see what you can craft with a core, check your recipe book in a crafting table. "
    }
}