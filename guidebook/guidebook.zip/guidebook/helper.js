import * as ui from "@minecraft/server-ui";

/**
 * Returns a color code for a given letter (A to I).
 * @param {string} letter - The letter to color.
 * @returns {string} - Minecraft color code.
 */
export function getColorForLetter(letter) {
    const colorMap = {
        A: "§c", // Red
        B: "§a", // Green
        C: "§b", // Aqua
        D: "§d", // Pink
        E: "§e", // Yellow
        F: "§6", // Gold
        G: "§9", // Blue
        H: "§2", // Dark Green
        I: "§5", // Purple
    };
    return colorMap[letter] || "§r"; // Default to reset color
}

export async function handleBackNavigation(source, actionForm, callback) {
    
    actionForm.show(source).then(async (toggleResult) => {
        if (!toggleResult.canceled && toggleResult.selection === 0) {
            await callback();
        }
    });
}

export function createSimpleActionForm(title, body, buttonText) {
    return new ui.ActionFormData()
        .title(title)
        .body(body)
        .button(buttonText);
}